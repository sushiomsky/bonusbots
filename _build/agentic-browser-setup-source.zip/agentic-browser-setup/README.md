# Agentic Browser Setup for Android

Small native Android setup assistant for Termux + Chromium/CDP + Hermes Agent.

## What the APK does

- Detects whether Termux is installed.
- Requests Termux's `com.termux.permission.RUN_COMMAND` dangerous permission.
- Copies the one-time `allow-external-apps = true` bootstrap and opens Termux.
- Installs/updates `termux-agent-browser` Tier 1 (Chromium/CDP).
- Optionally builds Tier 2 (`agent-browser`) on-device.
- Starts/restarts the Chromium headless service.
- Tests `http://127.0.0.1:9222/json/version` directly from Android.
- Applies current Hermes settings using `hermes config set`.
- Provides a full diagnostics command.

## First run

1. Install Termux from F-Droid/GitHub (not the obsolete Play Store build).
2. Tap **Copy bootstrap + open Termux** and paste/run the copied command once.
3. Return to this app and tap **Grant RUN_COMMAND permission**.
4. Tap **Install Tier 1 · Chromium/CDP**.
5. Tap **Apply Hermes CDP configuration** if Hermes is installed inside the same Termux environment.

## Build

Open the directory in Android Studio, or run:

```bash
./gradlew assembleDebug
```

The app deliberately uses only the Android framework and has no runtime dependencies.
